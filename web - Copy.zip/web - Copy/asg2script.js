async function sendApiRequest(){
	let api_id = ""
	let api_key = "8545f83405mshb9c2fc8f6c4d071p117b40jsnd59192ee6d9b"
	let response = await fetch ('https://rapidapi.com/amrelrafie/api/movies-tvshows-data-imdb?endpoint=apiendpoint_19cd80c4-9d24-4ee4-8297-756e66a9ae5c')
	console.log(response)
	let data = await response.json()
	console.log(data)
	userAPIData(data)
}